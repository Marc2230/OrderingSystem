
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.event.ChangeEvent;

public final class Dashboard extends javax.swing.JFrame {
        
    private int x = 0;
    
    public Dashboard() {
        initComponents();
        init();
        setupSpinners();
        
        
        
        
        //=======================//
        //Default Font for Header//
        //=======================//
        try {
            File fontStyle = new File("src/fonts/Anton-Regular.ttf");
            Font font;
            font = Font.createFont(Font.TRUETYPE_FONT,fontStyle).deriveFont(80f);
            Font font1 = Font.createFont(Font.TRUETYPE_FONT,fontStyle).deriveFont(14f);
            Font price = Font.createFont(Font.TRUETYPE_FONT,fontStyle).deriveFont(13f);
            Font quantity = Font.createFont(Font.TRUETYPE_FONT,fontStyle).deriveFont(13f);
            Font toggle = Font.createFont(Font.TRUETYPE_FONT,fontStyle).deriveFont(20f);
            jLabel1.setFont(font);
            jLabelPizza1.setFont(font1);
            jLabelPizza2.setFont(font1);
            jLabelPizza3.setFont(font1);
            jLabelPizza4.setFont(font1);
            jLabelPizza5.setFont(font1);
            jLabelPizza6.setFont(font1);
            
            price01.setFont(price);
            price02.setFont(price);
            price03.setFont(price);
            price04.setFont(price);
            price05.setFont(price);
            price06.setFont(price);
            price1.setFont(price);
            price2.setFont(price);
            price3.setFont(price);
            price4.setFont(price);
            price5.setFont(price);
            price6.setFont(price);
            
            quantity1.setFont(quantity);
            quantity2.setFont(quantity);
            quantity3.setFont(quantity);
            quantity4.setFont(quantity);
            quantity5.setFont(quantity);
            quantity6.setFont(quantity);
            
            jSpinner1.setFont(quantity);
            jSpinner2.setFont(quantity);
            jSpinner3.setFont(quantity);
            jSpinner4.setFont(quantity);
            jSpinner5.setFont(quantity);
            jSpinner6.setFont(quantity);
            
            toggle1.setFont(toggle);
            toggle2.setFont(toggle);
            toggle3.setFont(toggle);
            toggle4.setFont(toggle);
            toggle5.setFont(toggle);
            toggle6.setFont(toggle);
            
            //Fonts For Buttons
            OverallTotal.setFont(toggle);
            Exit.setFont(toggle);
            Clear.setFont(toggle);
            

            
        } catch (FontFormatException | IOException e) {
        }
        
        
        //=====================//
        //Logo for Havens Pizza//
        //=====================//
        
        Image icon;
        icon = new ImageIcon(this.getClass().getResource("/img/AppLogo.png")).getImage();
        this.setIconImage(icon);
        
    }
    
    private void init(){
        setImage();     
    }
     
    private void setImage(){
        ImageIcon icon = new ImageIcon(getClass().getResource("/img/TextLogo.png"));
        ImageIcon icon1 = new ImageIcon(getClass().getResource("/img/1.jpeg"));
        ImageIcon icon2 = new ImageIcon(getClass().getResource("/img/2.jpeg"));
        ImageIcon icon3 = new ImageIcon(getClass().getResource("/img/3.jpeg"));
        ImageIcon icon4 = new ImageIcon(getClass().getResource("/img/4.jpeg"));
        ImageIcon icon5 = new ImageIcon(getClass().getResource("/img/5.jpeg"));
        ImageIcon icon6 = new ImageIcon(getClass().getResource("/img/6.jpeg"));
        
 
        Image img = icon.getImage().getScaledInstance(jLabelTextLogo.getWidth(), jLabelTextLogo.getHeight(), Image.SCALE_SMOOTH);
        Image img1 = icon1.getImage().getScaledInstance(pizza1.getWidth(), pizza1.getHeight(), Image.SCALE_SMOOTH);
        Image img2 = icon2.getImage().getScaledInstance(pizza2.getWidth(), pizza2.getHeight(), Image.SCALE_SMOOTH);
        Image img3 = icon3.getImage().getScaledInstance(pizza3.getWidth(), pizza3.getHeight(), Image.SCALE_SMOOTH);
        Image img4 = icon4.getImage().getScaledInstance(pizza4.getWidth(), pizza4.getHeight(), Image.SCALE_SMOOTH);
        Image img5 = icon5.getImage().getScaledInstance(pizza5.getWidth(), pizza5.getHeight(), Image.SCALE_SMOOTH);
        Image img6 = icon6.getImage().getScaledInstance(pizza6.getWidth(), pizza6.getHeight(), Image.SCALE_SMOOTH);
        
        jLabelTextLogo.setIcon(new ImageIcon(img));
        pizza1.setIcon(new ImageIcon(img1));
        pizza2.setIcon(new ImageIcon(img2));
        pizza3.setIcon(new ImageIcon(img3));
        pizza4.setIcon(new ImageIcon(img4));
        pizza5.setIcon(new ImageIcon(img5));
        pizza6.setIcon(new ImageIcon(img6));
    }
    
    private void setupSpinners() {
          
      updateReceiptForSpinner(jSpinner1, jLabelPizza1.getText(), 199);
      updateReceiptForSpinner(jSpinner2, jLabelPizza2.getText(), 299);
      updateReceiptForSpinner(jSpinner3, jLabelPizza3.getText(), 299);
      updateReceiptForSpinner(jSpinner4, jLabelPizza4.getText(), 299);
      updateReceiptForSpinner(jSpinner5, jLabelPizza5.getText(), 399);
      updateReceiptForSpinner(jSpinner6, jLabelPizza6.getText(), 199);

          
        jSpinner1.addChangeListener((ChangeEvent e) -> {
            updateReceiptForSpinner(jSpinner1, jLabelPizza1.getText(), 199);
        });
        jSpinner2.addChangeListener((ChangeEvent e) -> {
            updateReceiptForSpinner(jSpinner2, jLabelPizza2.getText(), 299);
        });
        jSpinner3.addChangeListener((ChangeEvent e) -> {
            updateReceiptForSpinner(jSpinner3, jLabelPizza3.getText(), 299);
        });
        jSpinner4.addChangeListener((ChangeEvent e) -> {
            updateReceiptForSpinner(jSpinner4, jLabelPizza4.getText(), 299);
        });
        jSpinner5.addChangeListener((ChangeEvent e) -> {
            updateReceiptForSpinner(jSpinner5, jLabelPizza5.getText(), 399);
        });
        jSpinner6.addChangeListener((ChangeEvent e) -> {
            updateReceiptForSpinner(jSpinner6, jLabelPizza6.getText(), 199);
        });
}
    
    
    private void updateReceiptForSpinner(JSpinner spinner, String pizzaName, int pricePerUnit) {
        int qty = (int) spinner.getValue(); // Get the current quantity from the spinner

        if (qty > 0) {
            int totalPrice = qty * pricePerUnit; 
            String receiptText;
            if (pizzaName.equals("HAVEN'S FIREHOUSE") || pizzaName.equals("HAVEN'S SPECIAL")) {
                // Specific format for Pizza2 and Pizza5
                receiptText = String.format("%s\t\t\t %dx\t\t\t ₱%d\t\t\n", pizzaName, qty, totalPrice);
            } else {
                // Default format for other pizzas
                receiptText = String.format("%s\t\t %dx\t\t\t ₱%d\t\t\t\n", pizzaName, qty, totalPrice);
            }

            if (x == 0) {
                Receipt(); // Initialize receipt header
                x++;
            }

            // Update the receipt text, replacing the old entry
            receipt.setText(receipt.getText().replaceAll(pizzaName + ".*\n", "") + receiptText);

        } else {
            // Remove the pizza entry if quantity is zero
            receipt.setText(receipt.getText().replaceAll(pizzaName + ".*\n", ""));
        }
    }
   
    private boolean qtyIsZero(int qty){
        
        if (qty == 0) {
            JOptionPane.showMessageDialog(null, "Please Increase Item Quantity");
            return false;
        }
        
        return true;
        
    }
    
    private void Receipt(){
        
        receipt.setText("\n" + "\t\tProduct \t\t\tQty \t\t\tPrice\n"+"\n");
        
        
    }
    
    private void resetReceipt() {
        x = 0;
    }

    
    @Override
    public void enable(){
       
       jSpinner1.setEnabled(true);
       jSpinner2.setEnabled(true);
       jSpinner3.setEnabled(true);
       jSpinner4.setEnabled(true);
       jSpinner5.setEnabled(true);
       jSpinner6.setEnabled(true);
       OverallTotal.setEnabled(true);
   }
    @Override
   public void disable(){
       jSpinner1.setEnabled(false);
       jSpinner2.setEnabled(false);
       jSpinner3.setEnabled(false);
       jSpinner4.setEnabled(false);
       jSpinner5.setEnabled(false);
       jSpinner6.setEnabled(false);
       OverallTotal.setEnabled(false);
   }
    private void clear(){
        jSpinner1.setValue(0);
        jSpinner2.setValue(0);
        jSpinner3.setValue(0);
        jSpinner4.setValue(0);
        jSpinner5.setValue(0);
        jSpinner6.setValue(0);
        receipt.setText("");
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanelHeader = new javax.swing.JPanel();
        jLabelTextLogo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanelGarlicChicken = new javax.swing.JPanel();
        pizza1 = new javax.swing.JLabel();
        jLabelPizza1 = new javax.swing.JLabel();
        price01 = new javax.swing.JLabel();
        jLabelPizza8 = new javax.swing.JLabel();
        quantity1 = new javax.swing.JLabel();
        price1 = new javax.swing.JLabel();
        jSpinner1 = new javax.swing.JSpinner();
        toggle1 = new javax.swing.JToggleButton();
        jPanelFirehouse = new javax.swing.JPanel();
        pizza2 = new javax.swing.JLabel();
        jLabelPizza2 = new javax.swing.JLabel();
        price2 = new javax.swing.JLabel();
        price02 = new javax.swing.JLabel();
        quantity2 = new javax.swing.JLabel();
        toggle2 = new javax.swing.JToggleButton();
        jSpinner2 = new javax.swing.JSpinner();
        jPanelBbqChicken = new javax.swing.JPanel();
        pizza3 = new javax.swing.JLabel();
        jLabelPizza3 = new javax.swing.JLabel();
        price3 = new javax.swing.JLabel();
        price03 = new javax.swing.JLabel();
        quantity3 = new javax.swing.JLabel();
        toggle3 = new javax.swing.JToggleButton();
        jSpinner3 = new javax.swing.JSpinner();
        jPanelUltimateMeat = new javax.swing.JPanel();
        pizza4 = new javax.swing.JLabel();
        jLabelPizza4 = new javax.swing.JLabel();
        price4 = new javax.swing.JLabel();
        price04 = new javax.swing.JLabel();
        quantity4 = new javax.swing.JLabel();
        toggle4 = new javax.swing.JToggleButton();
        jSpinner4 = new javax.swing.JSpinner();
        jPanelSpecial = new javax.swing.JPanel();
        pizza5 = new javax.swing.JLabel();
        jLabelPizza5 = new javax.swing.JLabel();
        price5 = new javax.swing.JLabel();
        price05 = new javax.swing.JLabel();
        quantity5 = new javax.swing.JLabel();
        toggle5 = new javax.swing.JToggleButton();
        jSpinner5 = new javax.swing.JSpinner();
        jPanelVeggie = new javax.swing.JPanel();
        pizza6 = new javax.swing.JLabel();
        jLabelPizza6 = new javax.swing.JLabel();
        price6 = new javax.swing.JLabel();
        price06 = new javax.swing.JLabel();
        quantity6 = new javax.swing.JLabel();
        toggle6 = new javax.swing.JToggleButton();
        jSpinner6 = new javax.swing.JSpinner();
        ReceiptCon = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        receipt = new javax.swing.JTextArea();
        Exit = new javax.swing.JButton();
        OverallTotal = new javax.swing.JButton();
        Clear = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Haven's Pizza");
        setResizable(false);
        setSize(new java.awt.Dimension(1280, 720));

        jPanel1.setBackground(new java.awt.Color(186, 244, 151));
        jPanel1.setPreferredSize(new java.awt.Dimension(1280, 720));

        jPanelHeader.setBackground(new java.awt.Color(64, 100, 36));
        jPanelHeader.setPreferredSize(new java.awt.Dimension(1280, 100));
        jPanelHeader.setLayout(null);
        jPanelHeader.add(jLabelTextLogo);
        jLabelTextLogo.setBounds(710, 0, 120, 110);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 80)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 222, 89));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Slice of Ha    en");
        jPanelHeader.add(jLabel1);
        jLabel1.setBounds(0, 0, 1280, 130);

        jPanelGarlicChicken.setBackground(new java.awt.Color(255, 251, 230));
        jPanelGarlicChicken.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(103, 23, 23), 2));
        jPanelGarlicChicken.setPreferredSize(new java.awt.Dimension(180, 250));
        jPanelGarlicChicken.setRequestFocusEnabled(false);
        jPanelGarlicChicken.setLayout(null);

        pizza1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        jPanelGarlicChicken.add(pizza1);
        pizza1.setBounds(14, 8, 151, 80);

        jLabelPizza1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabelPizza1.setForeground(new java.awt.Color(96, 60, 18));
        jLabelPizza1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelPizza1.setText("HAVEN'S GARLIC CHICKEN");
        jPanelGarlicChicken.add(jLabelPizza1);
        jLabelPizza1.setBounds(14, 94, 151, 24);

        price01.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        price01.setForeground(new java.awt.Color(96, 60, 18));
        price01.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        price01.setText("₱199");
        jPanelGarlicChicken.add(price01);
        price01.setBounds(60, 140, 90, 30);

        jLabelPizza8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabelPizza8.setForeground(new java.awt.Color(96, 60, 18));
        jLabelPizza8.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabelPizza8.setText("PRICE : ");
        jPanelGarlicChicken.add(jLabelPizza8);
        jLabelPizza8.setBounds(0, 0, 0, 0);

        quantity1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        quantity1.setForeground(new java.awt.Color(96, 60, 18));
        quantity1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        quantity1.setText("QUANTITY :");
        jPanelGarlicChicken.add(quantity1);
        quantity1.setBounds(10, 170, 73, 30);

        price1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        price1.setForeground(new java.awt.Color(96, 60, 18));
        price1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        price1.setText("PRICE : ");
        jPanelGarlicChicken.add(price1);
        price1.setBounds(10, 140, 47, 30);

        jSpinner1.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));
        jSpinner1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jSpinner1.setRequestFocusEnabled(false);
        jSpinner1.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSpinner1StateChanged(evt);
            }
        });
        jPanelGarlicChicken.add(jSpinner1);
        jSpinner1.setBounds(70, 170, 100, 30);

        toggle1.setBackground(new java.awt.Color(103, 23, 23));
        toggle1.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        toggle1.setForeground(new java.awt.Color(255, 255, 255));
        toggle1.setText("RESET");
        toggle1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toggle1ActionPerformed(evt);
            }
        });
        jPanelGarlicChicken.add(toggle1);
        toggle1.setBounds(10, 210, 160, 30);

        jPanelFirehouse.setBackground(new java.awt.Color(255, 251, 230));
        jPanelFirehouse.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(103, 23, 23), 2, true));
        jPanelFirehouse.setPreferredSize(new java.awt.Dimension(180, 250));

        pizza2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));

        jLabelPizza2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabelPizza2.setForeground(new java.awt.Color(96, 60, 18));
        jLabelPizza2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelPizza2.setText("HAVEN'S FIREHOUSE");

        price2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        price2.setForeground(new java.awt.Color(96, 60, 18));
        price2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        price2.setText("PRICE : ");

        price02.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        price02.setForeground(new java.awt.Color(96, 60, 18));
        price02.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        price02.setText("₱299");

        quantity2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        quantity2.setForeground(new java.awt.Color(96, 60, 18));
        quantity2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        quantity2.setText("QUANTITY :");

        toggle2.setBackground(new java.awt.Color(103, 23, 23));
        toggle2.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        toggle2.setForeground(new java.awt.Color(255, 255, 255));
        toggle2.setText("RESET");
        toggle2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toggle2ActionPerformed(evt);
            }
        });

        jSpinner2.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));
        jSpinner2.setMaximumSize(new java.awt.Dimension(64, 22));

        javax.swing.GroupLayout jPanelFirehouseLayout = new javax.swing.GroupLayout(jPanelFirehouse);
        jPanelFirehouse.setLayout(jPanelFirehouseLayout);
        jPanelFirehouseLayout.setHorizontalGroup(
            jPanelFirehouseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelFirehouseLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanelFirehouseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanelFirehouseLayout.createSequentialGroup()
                        .addComponent(price2)
                        .addGap(3, 3, 3)
                        .addComponent(price02, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanelFirehouseLayout.createSequentialGroup()
                        .addComponent(quantity2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSpinner2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jLabelPizza2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pizza2, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE))
                .addContainerGap(13, Short.MAX_VALUE))
            .addGroup(jPanelFirehouseLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(toggle2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanelFirehouseLayout.setVerticalGroup(
            jPanelFirehouseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelFirehouseLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(pizza2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelPizza2, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanelFirehouseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(price2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(price02, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(4, 4, 4)
                .addGroup(jPanelFirehouseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(quantity2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSpinner2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(toggle2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(8, Short.MAX_VALUE))
        );

        jPanelBbqChicken.setBackground(new java.awt.Color(255, 251, 230));
        jPanelBbqChicken.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(103, 23, 23), 2, true));
        jPanelBbqChicken.setPreferredSize(new java.awt.Dimension(180, 250));

        pizza3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));

        jLabelPizza3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabelPizza3.setForeground(new java.awt.Color(96, 60, 18));
        jLabelPizza3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelPizza3.setText("HAVEN'S BBQ CHICKEN");

        price3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        price3.setForeground(new java.awt.Color(96, 60, 18));
        price3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        price3.setText("PRICE : ");

        price03.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        price03.setForeground(new java.awt.Color(96, 60, 18));
        price03.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        price03.setText("₱299");

        quantity3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        quantity3.setForeground(new java.awt.Color(96, 60, 18));
        quantity3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        quantity3.setText("QUANTITY :");

        toggle3.setBackground(new java.awt.Color(103, 23, 23));
        toggle3.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        toggle3.setForeground(new java.awt.Color(255, 255, 255));
        toggle3.setText("RESET");
        toggle3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toggle3ActionPerformed(evt);
            }
        });

        jSpinner3.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));
        jSpinner3.setMaximumSize(new java.awt.Dimension(64, 22));

        javax.swing.GroupLayout jPanelBbqChickenLayout = new javax.swing.GroupLayout(jPanelBbqChicken);
        jPanelBbqChicken.setLayout(jPanelBbqChickenLayout);
        jPanelBbqChickenLayout.setHorizontalGroup(
            jPanelBbqChickenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelBbqChickenLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanelBbqChickenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanelBbqChickenLayout.createSequentialGroup()
                        .addComponent(price3)
                        .addGap(3, 3, 3)
                        .addComponent(price03, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanelBbqChickenLayout.createSequentialGroup()
                        .addComponent(quantity3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSpinner3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jLabelPizza3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pizza3, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
                    .addComponent(toggle3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(13, Short.MAX_VALUE))
        );
        jPanelBbqChickenLayout.setVerticalGroup(
            jPanelBbqChickenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelBbqChickenLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(pizza3, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelPizza3, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanelBbqChickenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(price3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(price03, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(4, 4, 4)
                .addGroup(jPanelBbqChickenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(quantity3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSpinner3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(toggle3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(8, Short.MAX_VALUE))
        );

        jPanelUltimateMeat.setBackground(new java.awt.Color(255, 251, 230));
        jPanelUltimateMeat.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(103, 23, 23), 2, true));
        jPanelUltimateMeat.setPreferredSize(new java.awt.Dimension(180, 250));

        pizza4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));

        jLabelPizza4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabelPizza4.setForeground(new java.awt.Color(96, 60, 18));
        jLabelPizza4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelPizza4.setText("HAVEN'S ULTIMATE MEAT");

        price4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        price4.setForeground(new java.awt.Color(96, 60, 18));
        price4.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        price4.setText("PRICE : ");

        price04.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        price04.setForeground(new java.awt.Color(96, 60, 18));
        price04.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        price04.setText("₱299");

        quantity4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        quantity4.setForeground(new java.awt.Color(96, 60, 18));
        quantity4.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        quantity4.setText("QUANTITY :");

        toggle4.setBackground(new java.awt.Color(103, 23, 23));
        toggle4.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        toggle4.setForeground(new java.awt.Color(255, 255, 255));
        toggle4.setText("RESET");
        toggle4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toggle4ActionPerformed(evt);
            }
        });

        jSpinner4.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));
        jSpinner4.setMaximumSize(new java.awt.Dimension(64, 22));

        javax.swing.GroupLayout jPanelUltimateMeatLayout = new javax.swing.GroupLayout(jPanelUltimateMeat);
        jPanelUltimateMeat.setLayout(jPanelUltimateMeatLayout);
        jPanelUltimateMeatLayout.setHorizontalGroup(
            jPanelUltimateMeatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelUltimateMeatLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelUltimateMeatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(toggle4, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanelUltimateMeatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanelUltimateMeatLayout.createSequentialGroup()
                            .addComponent(price4)
                            .addGap(3, 3, 3)
                            .addComponent(price04, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanelUltimateMeatLayout.createSequentialGroup()
                            .addComponent(quantity4)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jSpinner4, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jLabelPizza4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addComponent(pizza4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(13, Short.MAX_VALUE))
        );
        jPanelUltimateMeatLayout.setVerticalGroup(
            jPanelUltimateMeatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelUltimateMeatLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(pizza4, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelPizza4, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanelUltimateMeatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(price4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(price04, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(4, 4, 4)
                .addGroup(jPanelUltimateMeatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(quantity4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSpinner4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(toggle4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(8, Short.MAX_VALUE))
        );

        jPanelSpecial.setBackground(new java.awt.Color(255, 251, 230));
        jPanelSpecial.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(103, 23, 23), 2, true));
        jPanelSpecial.setPreferredSize(new java.awt.Dimension(180, 250));

        pizza5.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));

        jLabelPizza5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabelPizza5.setForeground(new java.awt.Color(96, 60, 18));
        jLabelPizza5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelPizza5.setText("HAVEN'S SPECIAL");

        price5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        price5.setForeground(new java.awt.Color(96, 60, 18));
        price5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        price5.setText("PRICE : ");

        price05.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        price05.setForeground(new java.awt.Color(96, 60, 18));
        price05.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        price05.setText("₱399");

        quantity5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        quantity5.setForeground(new java.awt.Color(96, 60, 18));
        quantity5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        quantity5.setText("QUANTITY :");

        toggle5.setBackground(new java.awt.Color(103, 23, 23));
        toggle5.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        toggle5.setForeground(new java.awt.Color(255, 255, 255));
        toggle5.setText("RESET");
        toggle5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toggle5ActionPerformed(evt);
            }
        });

        jSpinner5.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));
        jSpinner5.setMaximumSize(new java.awt.Dimension(64, 22));

        javax.swing.GroupLayout jPanelSpecialLayout = new javax.swing.GroupLayout(jPanelSpecial);
        jPanelSpecial.setLayout(jPanelSpecialLayout);
        jPanelSpecialLayout.setHorizontalGroup(
            jPanelSpecialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelSpecialLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanelSpecialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(toggle5, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
                    .addGroup(jPanelSpecialLayout.createSequentialGroup()
                        .addComponent(price5)
                        .addGap(3, 3, 3)
                        .addComponent(price05, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanelSpecialLayout.createSequentialGroup()
                        .addComponent(quantity5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSpinner5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jLabelPizza5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pizza5, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE))
                .addContainerGap(13, Short.MAX_VALUE))
        );
        jPanelSpecialLayout.setVerticalGroup(
            jPanelSpecialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelSpecialLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(pizza5, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelPizza5, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanelSpecialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(price5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(price05, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(4, 4, 4)
                .addGroup(jPanelSpecialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(quantity5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSpinner5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(toggle5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(8, Short.MAX_VALUE))
        );

        jPanelVeggie.setBackground(new java.awt.Color(255, 251, 230));
        jPanelVeggie.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(103, 23, 23), 2, true));
        jPanelVeggie.setPreferredSize(new java.awt.Dimension(180, 250));

        pizza6.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));

        jLabelPizza6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabelPizza6.setForeground(new java.awt.Color(96, 60, 18));
        jLabelPizza6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelPizza6.setText("HAVEN'S GARDEN VEGGIE");

        price6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        price6.setForeground(new java.awt.Color(96, 60, 18));
        price6.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        price6.setText("PRICE : ");

        price06.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        price06.setForeground(new java.awt.Color(96, 60, 18));
        price06.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        price06.setText("₱199");

        quantity6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        quantity6.setForeground(new java.awt.Color(96, 60, 18));
        quantity6.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        quantity6.setText("QUANTITY :");

        toggle6.setBackground(new java.awt.Color(103, 23, 23));
        toggle6.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        toggle6.setForeground(new java.awt.Color(255, 255, 255));
        toggle6.setText("RESET");
        toggle6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toggle6ActionPerformed(evt);
            }
        });

        jSpinner6.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));
        jSpinner6.setMaximumSize(new java.awt.Dimension(64, 22));

        javax.swing.GroupLayout jPanelVeggieLayout = new javax.swing.GroupLayout(jPanelVeggie);
        jPanelVeggie.setLayout(jPanelVeggieLayout);
        jPanelVeggieLayout.setHorizontalGroup(
            jPanelVeggieLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelVeggieLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanelVeggieLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanelVeggieLayout.createSequentialGroup()
                        .addComponent(price6)
                        .addGap(3, 3, 3)
                        .addComponent(price06, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanelVeggieLayout.createSequentialGroup()
                        .addComponent(quantity6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSpinner6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jLabelPizza6, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(pizza6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(toggle6, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE))
                .addContainerGap(13, Short.MAX_VALUE))
        );
        jPanelVeggieLayout.setVerticalGroup(
            jPanelVeggieLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelVeggieLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(pizza6, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelPizza6, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanelVeggieLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(price6, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(price06, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(4, 4, 4)
                .addGroup(jPanelVeggieLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(quantity6, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSpinner6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(toggle6, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(8, Short.MAX_VALUE))
        );

        ReceiptCon.setBackground(new java.awt.Color(186, 244, 151));
        ReceiptCon.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 3, true), "Haven's Pizza", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Verdana", 3, 24), new java.awt.Color(103, 23, 23))); // NOI18N

        receipt.setEditable(false);
        receipt.setBackground(new java.awt.Color(255, 255, 255));
        receipt.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        receipt.setLineWrap(true);
        receipt.setTabSize(3);
        receipt.setWrapStyleWord(true);
        receipt.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        receipt.setFocusable(false);
        receipt.setMargin(new java.awt.Insets(5, 5, 5, 5));
        receipt.setName(""); // NOI18N
        receipt.setOpaque(false);
        jScrollPane1.setViewportView(receipt);

        Exit.setBackground(new java.awt.Color(0, 0, 102));
        Exit.setForeground(new java.awt.Color(255, 255, 255));
        Exit.setText("Exit");
        Exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitActionPerformed(evt);
            }
        });

        OverallTotal.setBackground(new java.awt.Color(76, 75, 22));
        OverallTotal.setForeground(new java.awt.Color(255, 255, 255));
        OverallTotal.setText("Total");
        OverallTotal.setPreferredSize(new java.awt.Dimension(70, 20));
        OverallTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OverallTotalActionPerformed(evt);
            }
        });

        Clear.setBackground(new java.awt.Color(103, 23, 23));
        Clear.setForeground(new java.awt.Color(255, 255, 255));
        Clear.setText("Clear");
        Clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ReceiptConLayout = new javax.swing.GroupLayout(ReceiptCon);
        ReceiptCon.setLayout(ReceiptConLayout);
        ReceiptConLayout.setHorizontalGroup(
            ReceiptConLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ReceiptConLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(ReceiptConLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ReceiptConLayout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 1, Short.MAX_VALUE))
                    .addGroup(ReceiptConLayout.createSequentialGroup()
                        .addComponent(OverallTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Clear, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Exit, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        ReceiptConLayout.setVerticalGroup(
            ReceiptConLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ReceiptConLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 437, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(ReceiptConLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(OverallTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Exit, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Clear, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanelHeader, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(53, 53, 53)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanelUltimateMeat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanelGarlicChicken, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(90, 90, 90)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanelFirehouse, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanelSpecial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(90, 90, 90)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanelVeggie, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanelBbqChicken, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ReceiptCon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanelHeader, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jPanelGarlicChicken, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanelSpecial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanelVeggie, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanelUltimateMeat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(43, 43, 43))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(22, 22, 22)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jPanelFirehouse, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jPanelBbqChicken, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(ReceiptCon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void toggle6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toggle6ActionPerformed
        //toggle6
        resetReceipt();
        jSpinner6.setValue(0);
    }//GEN-LAST:event_toggle6ActionPerformed

    
    private void toggle2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toggle2ActionPerformed
         //toggle2
        resetReceipt();
        jSpinner2.setValue(0);
    }//GEN-LAST:event_toggle2ActionPerformed

    private void toggle3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toggle3ActionPerformed
         //toggle3
        resetReceipt();
        jSpinner3.setValue(0);
    }//GEN-LAST:event_toggle3ActionPerformed

    private void toggle4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toggle4ActionPerformed
        //toggle4
        resetReceipt();
        jSpinner4.setValue(0);
    }//GEN-LAST:event_toggle4ActionPerformed

    private void toggle5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toggle5ActionPerformed
        //toggle5
        resetReceipt();
        jSpinner5.setValue(0);
    }//GEN-LAST:event_toggle5ActionPerformed

    private void toggle1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toggle1ActionPerformed
        //toggle1
        resetReceipt();
        jSpinner1.setValue(0);
    }//GEN-LAST:event_toggle1ActionPerformed

    private void jSpinner1StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSpinner1StateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_jSpinner1StateChanged

    private void ExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitActionPerformed
        System.exit(0);
    }//GEN-LAST:event_ExitActionPerformed

    private void OverallTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OverallTotalActionPerformed
        int overallTotal = 0;

        // Calculate total for each pizza based on the quantity in the spinners
        overallTotal += (int) jSpinner1.getValue() * 199; // Garlic Chicken
        overallTotal += (int) jSpinner2.getValue() * 299; // Firehouse
        overallTotal += (int) jSpinner3.getValue() * 299; // BBQ Chicken
        overallTotal += (int) jSpinner4.getValue() * 299; // Ultimate Meat
        overallTotal += (int) jSpinner5.getValue() * 399; // Special
        overallTotal += (int) jSpinner6.getValue() * 199; // Garden Veggie

        // Check if overall total is greater than zero
        if (overallTotal > 0) {
            // Update the receipt text area
            receipt.setText(receipt.getText() + String.format("Overall Total:\t\t\t\t\t\t\t ₱%d\n", overallTotal));
            disable(); // Disable spinners and buttons after calculating total
        } else {
            qtyIsZero(0); // Show message if no items are ordered
        }
    
    }//GEN-LAST:event_OverallTotalActionPerformed

    private void ClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearActionPerformed
        clear(); // Reset spinners
        receipt.setText(""); // Clear the receipt text area
        enable(); // Enable all spinners and buttons
        resetReceipt();
    }//GEN-LAST:event_ClearActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Dashboard().setVisible(true);
        });
    }

    private void getImage() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Clear;
    private javax.swing.JButton Exit;
    private javax.swing.JButton OverallTotal;
    private javax.swing.JPanel ReceiptCon;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabelPizza1;
    private javax.swing.JLabel jLabelPizza2;
    private javax.swing.JLabel jLabelPizza3;
    private javax.swing.JLabel jLabelPizza4;
    private javax.swing.JLabel jLabelPizza5;
    private javax.swing.JLabel jLabelPizza6;
    private javax.swing.JLabel jLabelPizza8;
    private javax.swing.JLabel jLabelTextLogo;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanelBbqChicken;
    private javax.swing.JPanel jPanelFirehouse;
    private javax.swing.JPanel jPanelGarlicChicken;
    private javax.swing.JPanel jPanelHeader;
    private javax.swing.JPanel jPanelSpecial;
    private javax.swing.JPanel jPanelUltimateMeat;
    private javax.swing.JPanel jPanelVeggie;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JSpinner jSpinner2;
    private javax.swing.JSpinner jSpinner3;
    private javax.swing.JSpinner jSpinner4;
    private javax.swing.JSpinner jSpinner5;
    private javax.swing.JSpinner jSpinner6;
    private javax.swing.JLabel pizza1;
    private javax.swing.JLabel pizza2;
    private javax.swing.JLabel pizza3;
    private javax.swing.JLabel pizza4;
    private javax.swing.JLabel pizza5;
    private javax.swing.JLabel pizza6;
    private javax.swing.JLabel price01;
    private javax.swing.JLabel price02;
    private javax.swing.JLabel price03;
    private javax.swing.JLabel price04;
    private javax.swing.JLabel price05;
    private javax.swing.JLabel price06;
    private javax.swing.JLabel price1;
    private javax.swing.JLabel price2;
    private javax.swing.JLabel price3;
    private javax.swing.JLabel price4;
    private javax.swing.JLabel price5;
    private javax.swing.JLabel price6;
    private javax.swing.JLabel quantity1;
    private javax.swing.JLabel quantity2;
    private javax.swing.JLabel quantity3;
    private javax.swing.JLabel quantity4;
    private javax.swing.JLabel quantity5;
    private javax.swing.JLabel quantity6;
    private javax.swing.JTextArea receipt;
    private javax.swing.JToggleButton toggle1;
    private javax.swing.JToggleButton toggle2;
    private javax.swing.JToggleButton toggle3;
    private javax.swing.JToggleButton toggle4;
    private javax.swing.JToggleButton toggle5;
    private javax.swing.JToggleButton toggle6;
    // End of variables declaration//GEN-END:variables
}
